
create --drop 
table Answers
(
	Id uniqueidentifier,
	QuestionId uniqueidentifier,
	Text nvarchar(50) 
)
