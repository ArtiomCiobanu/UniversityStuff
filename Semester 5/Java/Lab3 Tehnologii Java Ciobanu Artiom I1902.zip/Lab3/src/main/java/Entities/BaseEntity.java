package Entities;

import java.util.UUID;

public class BaseEntity
{
    public UUID Id;
}
