package Entities;

public class Question extends BaseEntity
{
    public String Name;
}
