package Entities;

import java.util.UUID;

public class Answer extends BaseEntity
{
    public UUID QuestionId;
    public String Text;
}
