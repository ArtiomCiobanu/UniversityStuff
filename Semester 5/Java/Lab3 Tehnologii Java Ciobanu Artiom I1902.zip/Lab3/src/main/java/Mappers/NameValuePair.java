package Mappers;

public class NameValuePair
{
    public String Name;
    public String Value;

    public NameValuePair()
    {

    }

    public NameValuePair(String name, String value)
    {
        this.Name = name;
        this.Value = value;
    }
}
