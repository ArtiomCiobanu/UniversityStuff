
create --drop 
table Questions
(
	Id uniqueidentifier,
	Name nvarchar(50)
)
